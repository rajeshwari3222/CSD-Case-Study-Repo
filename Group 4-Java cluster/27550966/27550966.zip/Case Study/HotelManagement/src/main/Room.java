package main;

public class Room {

	private int room_id;
	private int room_number;
	private String type;
	private int price_per_night;
	private String status;
	
	public Room(int room_number, String type, int price_per_night, String status) {
		super();
		this.room_number = room_number;
		this.type = type;
		this.price_per_night = price_per_night;
		this.status = status;
	}
	public Room() {
		super();
	}
	public Room(int room_id, int room_number, String type, int price_per_night, String status) {
		super();
		this.room_id = room_id;
		this.room_number = room_number;
		this.type = type;
		this.price_per_night = price_per_night;
		this.status = status;
	}
	public int getRoom_id() {
		return room_id;
	}
	public void setRoom_id(int room_id) {
		this.room_id = room_id;
	}
	public int getRoom_number() {
		return room_number;
	}
	public void setRoom_number(int room_number) {
		this.room_number = room_number;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public int getPrice_per_night() {
		return price_per_night;
	}
	public void setPrice_per_night(int price_per_night) {
		this.price_per_night = price_per_night;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
}
