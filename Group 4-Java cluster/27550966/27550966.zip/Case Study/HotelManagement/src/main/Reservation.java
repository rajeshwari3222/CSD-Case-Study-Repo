package main;

public class Reservation {
    private int reservation_id ;
	private int room_id;
	private int	customer_id ;
	private String check_in_date;
	private String	check_out_date;
	private String	status;
	
	@Override
	public String toString() {
		return "Reservation [reservation_id=" + reservation_id + ", room_id=" + room_id + ", customer_id=" + customer_id
				+ ", check_in_date=" + check_in_date + ", check_out_date=" + check_out_date + ", status=" + status
				+ "]";
	}
	public Reservation() {
		super();
	}
	public Reservation(int room_id, int customer_id, String check_in_date, String check_out_date, String status) {
		super();
		this.room_id = room_id;
		this.customer_id = customer_id;
		this.check_in_date = check_in_date;
		this.check_out_date = check_out_date;
		this.status = status;
	}
	public Reservation(int reservation_id, int room_id, int customer_id, String check_in_date, String check_out_date,
			String status) {
		super();
		this.reservation_id = reservation_id;
		this.room_id = room_id;
		this.customer_id = customer_id;
		this.check_in_date = check_in_date;
		this.check_out_date = check_out_date;
		this.status = status;
	}
	public int getReservation_id() {
		return reservation_id;
	}
	public void setReservation_id(int reservation_id) {
		this.reservation_id = reservation_id;
	}
	public int getRoom_id() {
		return room_id;
	}
	public void setRoom_id(int room_id) {
		this.room_id = room_id;
	}
	public int getCustomer_id() {
		return customer_id;
	}
	public void setCustomer_id(int customer_id) {
		this.customer_id = customer_id;
	}
	public String getCheck_in_date() {
		return check_in_date;
	}
	public void setCheck_in_date(String check_in_date) {
		this.check_in_date = check_in_date;
	}
	public String getCheck_out_date() {
		return check_out_date;
	}
	public void setCheck_out_date(String check_out_date) {
		this.check_out_date = check_out_date;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}

}
