package main;

import java.sql.Connection;

import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

public class Services {
	// Room Services
		public void addRoom(Room room) {
			
		try {
			Connection con  = InitConnection.createConnection();
			Statement stmt = con.createStatement();
			
			String sql = "INSERT INTO room (room_number, type, price_per_night, status) VALUES("+room.getRoom_number()+", '"+room.getType()+"', "+ room.getPrice_per_night()+", '"+room.getStatus()+"')";
			int result = stmt.executeUpdate(sql);
            System.out.println("Successful: "+ result);			
            con.close();
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e);
		}
		}
		
		public void viewRoom() {
			try {
				Connection con = InitConnection.createConnection(); 
				Statement stmt = con.createStatement();
				
				String sql = "SELECT * FROM room";
				ResultSet result = stmt.executeQuery(sql);
	            
	            while(result.next()) {
	            	System.out.println("room_id="+result.getInt(1)+", room_number="+result.getInt(2)+", type="+result.getString(3)+", price_per_night="+result.getInt(4)+", Status= "+result.getString(5));
	                System.out.println("------------------------------------------------------------------------------------------------------------");
	            }
	            con.close();
			} 
			catch (Exception e) {
				
				System.out.println(e);
			}
			
		}
		
		public void updateRoom(int id) {
			try {
				Connection con  = InitConnection.createConnection(); 
				Statement stmt = con.createStatement();
				
				 Scanner sc = new Scanner(System.in);
				 Room room = new Room();
				  System.out.println("Enter Room Number: ");
				  room.setRoom_number(sc.nextInt());
				  sc.nextLine();  

				  System.out.println("Enter Room Type: ");
				  String type = sc.nextLine();
				  room.setType(type);
				

				  System.out.println("Enter Price/Night Amount: ");
				  room.setPrice_per_night(sc.nextInt());
				  sc.nextLine();  
				  
				  System.out.println("Enter Status (available / book): ");
				  room.setStatus(sc.nextLine());
			

				  String sql = "UPDATE room SET room_number="+ room.getRoom_number()+", type='"+ room.getType()+"',  price_per_night="+room.getPrice_per_night()+", status= '"+ room.getStatus()+"' WHERE room_id="+ id+";";
				  int result = stmt.executeUpdate(sql);
	              
				  if(result > 0) {
					  System.out.println("Successfully Updated");
				  }
				  else {
					  System.out.println("Not Updated anything");
				  }
				  con.close();
			} 
			catch (Exception e) {
				// TODO: handle exception
				System.out.println(e);
			}
		}
		
		public void deleteRoom(int id) {
			
			try {
				Connection con  = InitConnection.createConnection();
				Statement stmt = con.createStatement();
				String sql = "DELETE FROM room WHERE room_id="+ id+";";
				
			    int result = stmt.executeUpdate(sql);
                if(result > 0 ) {
                	System.out.println("Room Deleted Successfully");
                }
                else {
                	System.out.println("You have given invalid Id");
                }
                con.close();
			} catch (Exception e) {
				// TODO: handle exception
			}
			
		}
		
		// Customer Services
		public void registerCustomer(Customer customer) {
			try {
				Connection con  = InitConnection.createConnection();
				Statement stmt = con.createStatement();
				System.out.println(customer);
				String sql = "INSERT INTO customer (name, email, phone, address) VALUES('"+customer.getName()+"', '"+customer.getEmail()+"', '"+ customer.getPhone_number()+"', '"+customer.getAddress()+"')";
				int result = stmt.executeUpdate(sql);
				if( result > 0) {
					 System.out.println("Successully registerd");			
				}
				else {
					System.out.println("Something went wrong");
				}
				con.close();
			} catch (Exception e) {
				// TODO: handle exception
				System.out.println(e);
			}
		}
		public void viewCustomer() {
			try {
				Connection con = InitConnection.createConnection(); 
				Statement stmt = con.createStatement();
				
				String sql = "SELECT * FROM customer;";
				ResultSet result = stmt.executeQuery(sql);
	            
	            while(result.next()) {
	            	Customer customer = new Customer(result.getInt(1), result.getString(2), result.getString(3), result.getString(4), result.getString(5));
	            	System.out.println(customer);
	            }
	            con.close();
			} 
			catch (Exception e) {
				// TODO: handle exception
				System.out.println(e);
			}
		}
		
		public void updateCustomer(int id) {
			try {
				Connection con  = InitConnection.createConnection(); 
				Statement stmt = con.createStatement();
				
				 Scanner sc = new Scanner(System.in);
				 Customer customer = new Customer();
				 
				  System.out.println("Enter Customer Name: ");
				  String name = sc.nextLine();
				  customer.setName(name);

				  System.out.println("Enter Customer Email Id: ");
				  String email = sc.nextLine();
				  customer.setEmail(email);
				  

				  System.out.println("Enter Phone Number: ");
				  String phone = sc.nextLine();
				  customer.setPhone_number(phone);;
			 

				  System.out.println("Enter Customer Address: ");
				  String address = sc.nextLine();
				  customer.setAddress(address);
				    
				  String sql = "UPDATE customer SET name='"+ customer.getName()+"', email='"+ customer.getEmail()+"',  phone='"+customer.getPhone_number()+"', address= '"+ customer.getAddress()+"' WHERE customer_id="+ id+";";
				  int result = stmt.executeUpdate(sql);
	              
				  if(result > 0) {
					  System.out.println("Successfully Updated");
				  }
				  else {
					  System.out.println("You have given invalid Id");
				  }
				  con.close();
			} 
			catch (Exception e) {
				// TODO: handle exception
				System.out.println(e);
			}
			
		}
		
		public void deleteCustomer(int id) {
			try {
				Connection con  = InitConnection.createConnection();
				Statement stmt = con.createStatement();
				String sql = "DELETE FROM customer WHERE customer_id="+ id+";";
				
			    int result = stmt.executeUpdate(sql);
                if(result > 0 ) {
                	System.out.println("Customer Deleted Successfully");
                }
                else {
                	System.out.println("You have given invalid Id");
                }
                con.close();
			} catch (Exception e) {
				// TODO: handle exception
			}
			
			
		}
		
		// Reservation Services
		public void makeReservation(Reservation reservation) {
			try {
				Connection con  = InitConnection.createConnection();
				Statement stmt = con.createStatement();
				System.out.println(reservation);
				String sql = "INSERT INTO reservation (room_id, customer_id, check_in, check_out, status) VALUES("+reservation.getRoom_id()+", "+reservation.getCustomer_id()+", '"+ reservation.getCheck_in_date()+"', '"+reservation.getCheck_out_date()+"', '"+ reservation.getStatus()+"')";
				int result = stmt.executeUpdate(sql);
				if( result > 0) {
					 System.out.println("Successully submitted");			
				}
				else {
					System.out.println("Something went wrong");
				}
				con.close();
			} catch (Exception e) {	
				// TODO: handle exception
				System.out.println(e.getMessage());
				System.out.println("Invalid room_id or customer_id");
			}

			
		}
		public void viewReservation() {
			try {
				Connection con = InitConnection.createConnection(); 
				Statement stmt = con.createStatement();
				
				String sql = "SELECT * FROM reservation;";
				ResultSet result = stmt.executeQuery(sql);
	            
	            while(result.next()) {
	            	Reservation reservation= new Reservation(result.getInt(1), result.getInt(2), result.getInt(3), result.getString(4), result.getString(5), result.getString(6));
	            	System.out.println(reservation);
	            }
	            con.close();
			} 
			catch (Exception e) {
				// TODO: handle exception
				System.out.println(e);
			}
		}
			
		
			
		public void cancelReservation(int id) {
			try {
				Services services = new Services();
				Connection con  = InitConnection.createConnection();
				Statement stmt = con.createStatement();
				String sql = "DELETE FROM reservation WHERE reservation_id="+ id+";";
				
			    int res = stmt.executeUpdate(sql);
                
			  
			    	System.out.println("Reservation Canceled Successfully");
			    
                  
                con.close();
			} catch (Exception e) {
				// TODO: handle exception
				System.out.println(e);
			}
		}
		
		public void updateRoomStatus(int id, String status) {
			try {
				  Connection con  = InitConnection.createConnection(); 
				  Statement stmt = con.createStatement();
				    
				  String sql = "UPDATE room SET status= '"+status+"' WHERE room_id="+ id+";";
				  int result = stmt.executeUpdate(sql);
	              System.out.println(result);
				  if(result > 0) {
					  System.out.println("Successfully status Updated");
				  }
				  else {
					  System.out.println("You have given invalid Id");
				  }
	              
				  con.close();
			} 
			catch (Exception e) {
				// TODO: handle exception
				System.out.println(e);
			}
		}
		
		public void updateReservationStatus(int id) {
			try {
				  Connection con  = InitConnection.createConnection(); 
				  Statement stmt = con.createStatement();
				    
				  String sql = "UPDATE reservation SET status= 'canceled' WHERE reservation_id="+ id+";";
				  int result = stmt.executeUpdate(sql);
	              System.out.println(result);
				  if(result > 0) {
					  System.out.println("Successfully status Updated");
				  }
				  else {
					  System.out.println("You have given invalid Id");
				  }
	              
				  con.close();
			} 
			catch (Exception e) {
				// TODO: handle exception
				System.out.println(e);
			}
		}
		public void listAllReservationForCustomer(int customer_id) {
			try {
				Connection con = InitConnection.createConnection(); 
				Statement stmt = con.createStatement();
				
				String sql = "SELECT * FROM reservation WHERE customer_id = "+customer_id+";";
				ResultSet result = stmt.executeQuery(sql);
	            
	            while(result.next()) {
	            	Reservation reservation = new Reservation(result.getInt(1), result.getInt(2), result.getInt(3), result.getString(4), result.getString(5),result.getString(6));
	            	System.out.println(reservation);
	            }
	            con.close();
			} 
			catch (Exception e) {
				// TODO: handle exception
				System.out.println(e);
			}
		}
		
}
