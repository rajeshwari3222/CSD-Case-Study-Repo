package main;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Date;
import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		Services services = new Services();
		
			try {
	      int opt;
	      boolean iteration = true;
	      Scanner sc = new Scanner(System.in);
	     
			while(iteration) {
				System.out.println("1.	Add a new room\r\n"
						+ "2.	View room details\r\n"
						+ "3.	Update room information\r\n"
						+ "4.	Delete a room\r\n"
						+ "");
				System.out.println("5.	Register a new customer\r\n"
						+ "6.	View customer details\r\n"
						+ "7.	Update customer information\r\n"
						+ "8.	Delete a customer\r\n"
						+ "");
	            System.out.println("9.	Make a reservation for a customer\r\n"
	            		+ "10.	View reservation details\r\n"
	            		+ "11.	Cancel a reservation\r\n"
	            		+ "12.	List all reservations for a specific customer\r\n"
	            		+ "");
			
	            System.out.println("0. Exit");
				opt = sc.nextInt();
				switch(opt) {
				
				  case 0:{
					iteration = false;
					break;
				   }
				  case 1: 
				  {
					  Room room = new Room();
					  System.out.println("Enter Room Number: ");
					  room.setRoom_number(sc.nextInt());
					  sc.nextLine();  

					  System.out.println("Enter Room Type: ");
					  String type = sc.nextLine();
					  room.setType(type);

					  System.out.println("Enter Price Per Night: ");
					  room.setPrice_per_night(sc.nextInt());
                      sc.nextLine();
					  
					  System.out.println("Enter Status: ");
					  room.setStatus(sc.nextLine());
					

					  services.addRoom(room);
					  	
				      break;
				  }
				
			     case 2: {
					services.viewRoom();
					break;
				  }
				  case 3: {
					  services.viewRoom();
					  System.out.println("Enter Room Id to be updated:");
					  int id = sc.nextInt();
					  services.updateRoom(id);
						break;
					  }
				  case 4: {
					  services.viewRoom();
					  System.out.println("Enter Room Id to be deleted:");
					  int id = sc.nextInt();
					  services.deleteRoom(id);
						break;
					  }
				  case 5: {
					  Customer customer = new Customer();
					  sc.nextLine();  
					  System.out.println("Enter Customer Name: ");
					  String name = sc.nextLine();
					  customer.setName(name);

					  System.out.println("Enter Customer Email Id: ");
					  String email = sc.nextLine();
					  customer.setEmail(email);
					  

					  System.out.println("Enter Phone Number: ");
					  String phone = sc.nextLine();
					  customer.setPhone_number(phone);;
				 

					  System.out.println("Enter Customer Address: ");
					  String address = sc.nextLine();
					  customer.setAddress(address);
					    

					  services.registerCustomer(customer);
					  	
						break;
					  }
				  case 6: {
					  services.viewCustomer();
						break;
					  }
				  case 7: {
					  services.viewCustomer();
					  System.out.println("Enter Customer Id to be updated:");
					  int id = sc.nextInt();
					  services.updateCustomer(id);
						break;
					  }
				  case 8: {
					  services.viewCustomer();
					  System.out.println("Enter Customer Id to be deleted:");
					   int id = sc.nextInt();
					   services.deleteCustomer(id);
						break;
					  }
				  case 9: {
					  
					  Reservation reservation = new Reservation();
			
					  services.viewRoom();
					  System.out.println("Enter Room Id (Only available rooms are allowed): ");
					  int room_id = sc.nextInt();
					  reservation.setRoom_id(room_id);

					  services.viewCustomer();
					  System.out.println("Enter Customer Id(Only available customer are allowed): ");
					  int customer_id = sc.nextInt();
					  reservation.setCustomer_id(customer_id);
					  sc.nextLine();
					
					  System.out.println("Enter Checkout date(yyyy-MM-dd) (should be greater than checkin date): ");
					  reservation.setCheck_in_date(sc.nextLine());
					
					  
					  System.out.println("Enter Checkout date(yyyy-MM-dd) (should be greater than checkin date): ");
					  reservation.setCheck_out_date(sc.nextLine());
					

					  System.out.println("Enter Reservation Status ( reserved/canceled ): ");
					  String status = sc.nextLine();
					  reservation.setStatus(status);	
					  
					  services.makeReservation(reservation);
					  break;
					  }
				  case 10: {
					  services.viewReservation();
						break;
					  }
				  case 11: {
					  services.viewReservation();
					  System.out.println("Enter Reservation Id to be deleted:");
					  int id = sc.nextInt();
					  services.cancelReservation(id);
					  break;
					  }
				  case 12: {
					  services.viewCustomer();
					  System.out.println("Enter Customer Id to get all reservations:");
					  int id = sc.nextInt();
					  services.listAllReservationForCustomer(id);
					  break;
						
					  }
				  case 13: {
					  services.viewReservation();
					  System.out.println("Enter Reservation Id to be updated:");
					  int id = sc.nextInt();
					  services.updateReservationStatus(id);
						break;
					  }
				  default:{
					System.out.println("Invalid Option, Choose valid option");
					break;
				  }
				}

			}
			sc.close();
			
			  } catch (Exception e) {
			
				  e.printStackTrace();
			  }

			
	}

}
