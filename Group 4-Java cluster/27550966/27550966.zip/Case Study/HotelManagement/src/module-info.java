/**
 * 
 */
/**
 * 
 */
module HotelManagement {
	requires java.sql;
}